<!-- jQuery -->
<script src="<?= HTTP_VENDOR_PATH ?>jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?= HTTP_VENDOR_PATH ?>bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?= HTTP_VENDOR_PATH ?>metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="<?= HTTP_VENDOR_PATH ?>raphael/raphael.min.js"></script>
<script src="<?= HTTP_VENDOR_PATH ?>morrisjs/morris.min.js"></script>
<script src="<?= HTTP_JS_PATH ?>morris-data.js"></script>

<script src="<?= HTTP_JS_PATH ?>pikaday.js"></script>
<script src="<?= HTTP_JS_PATH ?>pikaday.jquery.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?= HTTP_JS_PATH ?>sb-admin-2.js"></script>

</body>

</html>